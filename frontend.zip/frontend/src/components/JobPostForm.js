import React, { useState } from 'react';
import axios from 'axios';
import './JobPostForm.css';

const JobPostForm = () => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    skillsRequired: '',
    location: '',
    type: 'full-time',
  });

  const { title, description, skillsRequired, location, type } = formData;

  const onChange = e => setFormData({ ...formData, [e.target.name]: e.target.value });

  const onSubmit = async e => {
    e.preventDefault();
    const token = localStorage.getItem('token');
    try {
      const res = await axios.post('http://localhost:5000/api/jobs', formData, {
        headers: { 'x-auth-token': token },
      });
      console.log(res.data);
    } catch (err) {
      console.error(err.response.data);
    }
  };

  return (
    <form onSubmit={onSubmit}>
      <input type="text" name="title" value={title} onChange={onChange} placeholder="Job Title" required />
      <textarea name="description" value={description} onChange={onChange} placeholder="Job Description" required />
      <input type="text" name="skillsRequired" value={skillsRequired} onChange={onChange} placeholder="Skills Required (comma separated)" required />
      <input type="text" name="location" value={location} onChange={onChange} placeholder="Location" required />
      <select name="type" value={type} onChange={onChange}>
        <option value="full-time">Full-Time</option>
        <option value="part-time">Part-Time</option>
        <option value="remote">Remote</option>
        <option value="flexible">Flexible</option>
      </select>
      <button type="submit">Post Job</button>
    </form>
  );
};

export default JobPostForm;