import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './JobList.css';

const JobList = () => {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    const fetchJobs = async () => {
      const res = await axios.get('http://localhost:5000/api/jobs');
      setJobs(res.data);
    };
    fetchJobs();
  }, []);

  return (
    <div>
      {jobs.map(job => (
        <div key={job._id}>
          <h3>{job.title}</h3>
          <p>{job.description}</p>
          <p>Skills Required: {job.skillsRequired.join(', ')}</p>
          <p>Location: {job.location}</p>
          <p>Type: {job.type}</p>
          <p>Employer: {job.employer.name}</p>
        </div>
      ))}
    </div>
  );
};

export default JobList;